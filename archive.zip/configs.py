# Imports from external libraries


# Imports from internal libraries

SEED_SITES = [
    "gov.si",
    "evem.gov.si",
    "e-uprava.gov.si",
    "e-prostor.gov.si",
]

CHROME_DRIVER = "/home/erik/Documents/Projects/Faculty/web_information_extraction/crawling_gov/browser_drivers/chromedriver"

USERNAME = "erik"
PASSWORD = "1234"
HOST = "localhost"

AGENT_NAME = "user-agent=fri-ieps-TEST"